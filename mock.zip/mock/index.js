var express = require('express');
var app = express();
var mock = [
    {
        id : 1,
        name : "Fernando Fazolli",
        avatar : "http://localhost:3000/static/myAvatar1.png"
    },
    {
        id : 2,
        name : "Silvana Fazolli",
        avatar : "http://localhost:3000/static/myAvatar2.png"
    },
    {
        id : 3,
        name : "Ester Fazolli",
        avatar : "http://localhost:3000/static/myAvatar3.png"
    },
    {
        id : 4,
        name : "Ana Fazolli",
        avatar : "http://localhost:3000/static/myAvatar4.png"
    }
];



app.use((req, resp, next)=>{
    resp.header("Access-Control-Allow-Origin", "*");
    resp.header("Access-Control-Allow-Headers", "X-Requested-With");
    next();
});

app.use('/static', express.static('img'));

app.get('/users', (req, resp) => {
    resp.send(mock);
});

app.listen(3000, ()=>{
    console.log("iniciando a mock");
});